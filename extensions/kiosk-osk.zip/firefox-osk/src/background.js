// Background script for Firefox OSK
console.log("Firefox OSK Background script loaded");
